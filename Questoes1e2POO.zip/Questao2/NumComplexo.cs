﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Questao2
{
    static class Questao2
    {
  
        static void Main(string[] args)
        {
            //solicita ao usuário que digite a parte real do primeiro número complexo
            Console.WriteLine("Digite a parte real de z1:");
            //converte a entrada do usuário para um número double e armazena em real1
            double real1 = Convert.ToDouble(Console.ReadLine());

            //solicita ao usuário que digite a parte imaginária do primeiro número complexo
            Console.WriteLine("Digite a parte imaginária de z1:");
            // Converte a entrada do usuário para um número double e armazena em imaginario1
            double imaginario1 = Convert.ToDouble(Console.ReadLine());

            //solicita ao usuário que digite a parte real do segundo número complexo
            Console.WriteLine("Digite a parte real de z2:");
            // Converte a entrada do usuário para um número double e armazena em real2
            double real2 = Convert.ToDouble(Console.ReadLine());

            //solicita ao usuário que digite a parte imaginária do segundo número complexo
            Console.WriteLine("Digite a parte imaginária de z2:");
            //converte a entrada do usuário para um número double e armazena em imaginario2
            double imaginario2 = Convert.ToDouble(Console.ReadLine());

            //cria o primeiro número complexo usando as partes real e imaginária fornecidas
            NumComplexo z1 = new NumComplexo(real1, imaginario1);
            //cria o segundo número complexo usando as partes real e imaginária fornecidas
            NumComplexo z2 = new NumComplexo(real2, imaginario2);

            //calcula o módulo dos números complexo e exibe o resultado
            Console.WriteLine($"O módulo de z1 ({real1} + {imaginario1}i) é: {z1.Modulo()}");
            Console.WriteLine($"O módulo de z2 ({real2} + {imaginario2}i) é: {z2.Modulo()}");

            // Calcula a soma dos dois números complexos
            NumComplexo soma = z1.Soma(z2);
            Console.WriteLine("Forma polar da soma:");
            soma.ImprimeFormaPolar();

            // Calcula o produto dos dois números complexos
            NumComplexo produto = z1.Vezes(z2);
            // Exibe a forma polar do produto dos números complexos
            Console.WriteLine("Forma polar do produto:");
            produto.ImprimeFormaPolar();

            Console.ReadKey();
        }
    }
}
