﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Questao1
{
    static class Questao1
    {
        static void Main(string[] args)
        {
            //Solicita o nome completo do usuário
            Console.WriteLine("Digite o nome completo:");
            string nomeCompleto = Console.ReadLine();

            //cria objeto da classe NomeProprio
            NomeProprio nome = new NomeProprio(nomeCompleto);

            //imprime o nome no formato "paper" = utilizado pela plataforma Lattes/CNPq para elaboracao de curriculos online de professores e pesquisadores brasileiros.
            nome.ImprimeNomePaper();

            //deixa o console aberto até qualquer tecla ser pressionada
            Console.ReadKey();
        }
    }
}